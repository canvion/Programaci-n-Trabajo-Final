

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * Servlet implementation class MarcarPagadaServlet
 */
@WebServlet("/MarcarPagadaServlet") 
public class MarcarPagadaServlet extends HttpServlet {
  @Override
  protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
    resp.setHeader("Access-Control-Allow-Origin", "*");
    resp.setContentType("text/plain; charset=UTF-8");

    int justId = Integer.parseInt(req.getParameter("justificanteId"));
    try (Connection c = Bbdd.getConnection()) {
      // 1) Obtener deuda_id
      int deudaId;
      try (PreparedStatement p1 = c.prepareStatement(
             "SELECT deuda_id FROM justificantes WHERE id=?")) {
        p1.setInt(1, justId);
        try (ResultSet rs = p1.executeQuery()) {
          if (!rs.next()) throw new IllegalArgumentException("Justificante no existe");
          deudaId = rs.getInt("deuda_id");
        }
      }
      // 2) Marcar deuda como pagada
      try (PreparedStatement p2 = c.prepareStatement(
             "UPDATE deudas SET estado='pagada' WHERE id=?")) {
        p2.setInt(1, deudaId);
        p2.executeUpdate();
      }
      // 3) Marcar justificante como aceptado
      try (PreparedStatement p3 = c.prepareStatement(
             "UPDATE justificantes SET estado='aceptado' WHERE id=?")) {
        p3.setInt(1, justId);
        p3.executeUpdate();
      }
      resp.getWriter().write("Deuda marcada como pagada.");
    } catch (Exception e) {
      resp.setStatus(500);
      resp.getWriter().write("Error: " + e.getMessage());
      e.printStackTrace();
    }
  }
}
