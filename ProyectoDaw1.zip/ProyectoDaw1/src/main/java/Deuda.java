
import java.sql.Date;

public class Deuda {
    private int id;
    private String nombreApellidos;
    private Date fecha;
    private String motivo;
    private double cantidad;
    private String dni;
    private String email;
    private String estado;
    private byte[] foto;

    // getters y setters para cada campo
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNombreApellidos() { return nombreApellidos; }
    public void setNombreApellidos(String nombreApellidos) { this.nombreApellidos = nombreApellidos; }

    public Date getFecha() { return fecha; }
    public void setFecha(Date fecha) { this.fecha = fecha; }

    public String getMotivo() { return motivo; }
    public void setMotivo(String motivo) { this.motivo = motivo; }

    public double getCantidad() { return cantidad; }
    public void setCantidad(double cantidad) { this.cantidad = cantidad; }

    public String getDni() { return dni; }
    public void setDni(String dni) { this.dni = dni; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    
   public byte[] getFoto() {
        return foto;
    }

    // Setter para foto
    public void setFoto(byte[] foto) {
        this.foto = foto;
    }
}
