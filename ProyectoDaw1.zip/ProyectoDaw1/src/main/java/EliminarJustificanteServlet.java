
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 * Servlet implementation class EliminarJustificanteServlet
 */
@WebServlet("/EliminarJustificanteServlet")
public class EliminarJustificanteServlet extends HttpServlet {
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
    String id = request.getParameter("justificanteId");
    if (id == null) {
      response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Falta el ID");
      return;
    }

    try (Connection conn = Bbdd.getConnection()) {
      PreparedStatement stmt = conn.prepareStatement("DELETE FROM justificantes WHERE id = ?");
      stmt.setInt(1, Integer.parseInt(id));
      int filas = stmt.executeUpdate();
      response.setContentType("text/plain");
      response.getWriter().write(filas > 0 ? "Justificante eliminado correctamente" : "No se encontró el justificante");
    } catch (Exception e) {
      e.printStackTrace();
      response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error en el servidor");
    }
  }
}