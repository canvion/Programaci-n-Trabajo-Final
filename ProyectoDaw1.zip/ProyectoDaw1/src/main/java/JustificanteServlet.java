

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.IOException;
import java.io.InputStream;

/**
 * Servlet implementation class JustificanteServlet
 */
@WebServlet("/JustificanteServlet")
@MultipartConfig
public class JustificanteServlet extends HttpServlet {
  protected void doPost(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException {
    resp.setHeader("Access-Control-Allow-Origin", "*");
    req.setCharacterEncoding("UTF-8");

    try {
      int deudaId = Integer.parseInt(req.getParameter("deudaId"));
      String dni   = req.getParameter("dni");
      String email = req.getParameter("email");
      Part filePart = req.getPart("justificante");
      InputStream fileStream = filePart.getInputStream();

      // Inserta en tabla justificantes
      Bbdd.insertarJustificante(deudaId, dni, email, fileStream);

      resp.setContentType("text/plain; charset=UTF-8");
      resp.getWriter().write("Justificante enviado y pendiente de revisión.");
    } catch (Exception e) {
      resp.setStatus(500);
      resp.getWriter().write("Error enviando justificante: " + e.getMessage());
      e.printStackTrace();
    }
  }
  
  @Override
  protected void doGet(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException {
    resp.setHeader("Access-Control-Allow-Origin", "*");
    resp.setContentType("text/html; charset=UTF-8");

    // Llamamos al método que genera la tabla de justificantes pendientes
    String tabla = Bbdd.listarJustificantesHTML();
    resp.getWriter().write(tabla);
  }
}