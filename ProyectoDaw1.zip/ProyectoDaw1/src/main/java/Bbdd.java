import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Date;
import java.util.Base64;


public class Bbdd {
    private static final String DB_URL =
        "jdbc:mysql://localhost:3306/WebDeudas?useSSL=false&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "";
    
    
    public static Connection getConnection() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(DB_URL, USER, PASSWORD);
    }


    public static void insertarDeuda(
            String nombreApellidos,
            InputStream fotoStream,
            String fecha,
            String motivo,
            double cantidad,
            String dni,
            String email) throws SQLException, ClassNotFoundException {
        String sql = "INSERT INTO deudas " +
                   "(nombre_apellidos, foto, fecha, motivo, cantidad, dni, email) " +
                   "VALUES (?, ?, ?, ?, ?, ?, ?)";
        Class.forName("com.mysql.cj.jdbc.Driver");
        try (Connection con = DriverManager.getConnection(DB_URL, USER, PASSWORD);
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, nombreApellidos);
            pst.setBlob(2, fotoStream);
            pst.setDate(3, Date.valueOf(fecha));
            pst.setString(4, motivo);
            pst.setDouble(5, cantidad);
            pst.setString(6, dni);
            pst.setString(7, email);

            pst.executeUpdate();
        }
    }
    
    public static String listarDeudasHTML(String orden,
            boolean permitirEliminar,
            boolean permitirJustificar) {
StringBuilder html = new StringBuilder();
html.append("<table border='1' style='border-collapse:collapse;width:100%'>")
.append("<tr>")
.append("<th>ID</th>")
.append("<th>Nombre</th>")
.append("<th>Foto</th>")
.append("<th>Fecha</th>")
.append("<th>Motivo</th>")
.append("<th>Cantidad</th>")
.append("<th>DNI</th>")
.append("<th>Email</th>")
.append("<th>Estado</th>");
if (permitirEliminar) {
html.append("<th>Eliminar</th>")
.append("<th>Editar</th>");
}
if (permitirJustificar) {
html.append("<th>Justificar</th>");
}
// Nueva columna para PDF
html.append("<th>PDF</th>");
html.append("</tr>");

// Construir cláusula ORDER BY
String orderBy = "";
if (orden != null) {
String o = orden.trim().toLowerCase();
if (o.equals("asc")) {
orderBy = " ORDER BY cantidad ASC";
} else if (o.equals("desc")) {
orderBy = " ORDER BY cantidad DESC";
}
}

String sql = "SELECT * FROM deudas" + orderBy;

try {
Class.forName("com.mysql.cj.jdbc.Driver");
try (Connection con = DriverManager.getConnection(DB_URL, USER, PASSWORD);
Statement stm = con.createStatement();
ResultSet rs = stm.executeQuery(sql)) {

while (rs.next()) {
String estado = rs.getString("estado");
byte[] imgBytes = rs.getBytes("foto");
String base64 = (imgBytes != null && imgBytes.length > 0)
? Base64.getEncoder().encodeToString(imgBytes)
: "";

html.append("<tr>")
.append("<td>").append(rs.getInt("id")).append("</td>")
.append("<td>").append(rs.getString("nombre_apellidos")).append("</td>")
.append("<td>");
if (!base64.isEmpty()) {
html.append("<img src='data:image/jpeg;base64,")
.append(base64)
.append("' width='150' style='border-radius:8px'/>");
}
html.append("</td>")
.append("<td>").append(rs.getDate("fecha")).append("</td>")
.append("<td>").append(rs.getString("motivo")).append("</td>")
.append("<td>").append(rs.getDouble("cantidad")).append("</td>")
.append("<td>").append(rs.getString("dni")).append("</td>")
.append("<td>").append(rs.getString("email")).append("</td>")
.append("<td>").append(estado).append("</td>");

if (permitirEliminar) {
html.append("<td>")
.append("<button class='btnEliminar' data-id='")
.append(rs.getInt("id"))
.append("'>Eliminar</button>")
.append("</td>")
.append("<td>")
.append("<button class='btnEditar' data-id='")
.append(rs.getInt("id"))
.append("'>Editar</button>")
.append("</td>");
}

if (permitirJustificar) {
if ("pendiente".equalsIgnoreCase(estado)) {
html.append("<td>")
  .append("<button class='btnJustificar' data-id='")
  .append(rs.getInt("id"))
  .append("'>Justificar</button>")
  .append("</td>");
} else {
html.append("<td>&mdash;</td>");
}
}

// Celda PDF
html.append("<td>")
.append("<button class='btnPdf' data-id='")
.append(rs.getInt("id"))
.append("'>PDF</button>")
.append("</td>");

html.append("</tr>");
}
}
} catch (Exception e) {
e.printStackTrace();
return "<p>Error al listar deudas: " + e.getMessage() + "</p>";
}

html.append("</table>");
return html.toString();
}

    
    public static void insertarJustificante(int deudaId, String dni, String email, InputStream file) throws SQLException {
    	  String sql = "INSERT INTO justificantes(deuda_id,dni,email,archivo) VALUES(?,?,?,?)";
    	  try (Connection c = getConnection();
    	       PreparedStatement p = c.prepareStatement(sql)) {
    	    p.setInt(1, deudaId);
    	    p.setString(2, dni);
    	    p.setString(3, email);
    	    p.setBlob(4, file);
    	    p.executeUpdate();
    	  } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    public static String listarJustificantesHTML() {
        StringBuilder html = new StringBuilder();
        html.append("<table border='1' style='border-collapse:collapse;width:100%'>")
            .append("<tr>")
              .append("<th>ID Justificante</th>")
              .append("<th>ID Deuda</th>")
              .append("<th>DNI</th>")
              .append("<th>Email</th>")
              .append("<th>Fecha Envío</th>")
              .append("<th>Revisar</th>")
            .append("</tr>");

        String sql = "SELECT id, deuda_id, dni, email, fecha_envio "
                   + "FROM justificantes WHERE estado='pendiente'";

        try (Connection con = DriverManager.getConnection(DB_URL,USER,PASSWORD);
             Statement stm = con.createStatement();
             ResultSet rs = stm.executeQuery(sql)) {

            while (rs.next()) {
                html.append("<tr>")
                    .append("<td>").append(rs.getInt("id")).append("</td>")
                    .append("<td>").append(rs.getInt("deuda_id")).append("</td>")
                    .append("<td>").append(rs.getString("dni")).append("</td>")
                    .append("<td>").append(rs.getString("email")).append("</td>")
                    .append("<td>").append(rs.getTimestamp("fecha_envio")).append("</td>")
                    .append("<td>")
                      .append("<button class='btnRevisar' data-id='")
                      .append(rs.getInt("id"))
                      .append("'>Revisar justificante</button>")
                    .append("</td>")
                  .append("</tr>");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return "<p>Error al listar justificantes: " + e.getMessage() + "</p>";
        }

        html.append("</table>");
        return html.toString();
    }
    
    public static Deuda getDeudaPorId(int id) throws SQLException, ClassNotFoundException {
        String sql = "SELECT id, nombre_apellidos, foto, fecha, motivo, cantidad, dni, email, estado "
                   + "FROM deudas WHERE id = ?";
        Class.forName("com.mysql.cj.jdbc.Driver");
        try (Connection con = DriverManager.getConnection(DB_URL, USER, PASSWORD);
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, id);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    Deuda d = new Deuda();
                    d.setId(rs.getInt("id"));
                    d.setNombreApellidos(rs.getString("nombre_apellidos"));
                    d.setFecha(rs.getDate("fecha"));
                    d.setMotivo(rs.getString("motivo"));
                    d.setCantidad(rs.getDouble("cantidad"));
                    d.setDni(rs.getString("dni"));
                    d.setEmail(rs.getString("email"));
                    d.setEstado(rs.getString("estado"));
                    // No cargamos Blob foto aquí, tu JS no lo necesita
                    return d;
                } else {
                    throw new SQLException("No existe deuda con ID=" + id);
                }
            }
        }
    }


}
