
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 * Servlet implementation class EliminarDeudaServlet
 */
@WebServlet("/EliminarDeudaServlet")
public class EliminarDeudaServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setHeader("Access-Control-Allow-Origin", "*");

        String id = request.getParameter("id");

        try (Connection con = Bbdd.getConnection();
             PreparedStatement pst = con.prepareStatement("DELETE FROM deudas WHERE id=?")) {

            pst.setInt(1, Integer.parseInt(id));
            pst.executeUpdate();
            response.getWriter().write("Deuda eliminada correctamente.");

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("Error al eliminar la deuda.");
        }
    }
}
