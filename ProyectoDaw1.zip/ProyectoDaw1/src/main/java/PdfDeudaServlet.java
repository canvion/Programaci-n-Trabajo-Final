
import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.PdfPTable;



/**
 * Servlet implementation class PdfDeudaServlet
 */
@WebServlet("/PdfDeudaServlet")
public class PdfDeudaServlet extends HttpServlet {
  @Override
  protected void doGet(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {

    String idParam = req.getParameter("id");
    if (idParam == null || idParam.isEmpty()) {
      resp.sendError(400, "Falta parámetro id");
      return;
    }

    Deuda d;
    try {
      d = Bbdd.getDeudaPorId(Integer.parseInt(idParam));
    } catch (Exception e) {
      resp.sendError(500, "Error al leer deuda: " + e.getMessage());
      return;
    }

    resp.setContentType("application/pdf");
    resp.setHeader("Content-Disposition",
      "attachment; filename=deuda_" + d.getId() + ".pdf");

    Document pdf = new Document();
    try {
      PdfWriter.getInstance(pdf, resp.getOutputStream());
      pdf.open();

      // Título
      Paragraph title = new Paragraph("Detalle de Deuda #" + d.getId());
      title.setAlignment(Element.ALIGN_CENTER);
      title.setSpacingAfter(20);
      pdf.add(title);

      // Tabla 2 columnas
      PdfPTable table = new PdfPTable(2);
      table.setWidthPercentage(100);
      table.addCell("ID");       table.addCell(String.valueOf(d.getId()));
      table.addCell("Nombre");   table.addCell(d.getNombreApellidos());
      table.addCell("Fecha");    table.addCell(d.getFecha().toString());
      table.addCell("Motivo");   table.addCell(d.getMotivo());
      table.addCell("Cantidad"); table.addCell(String.format("%.2f €", d.getCantidad()));
      table.addCell("DNI");      table.addCell(d.getDni());
      table.addCell("Email");    table.addCell(d.getEmail());
      table.addCell("Estado");   table.addCell(d.getEstado());
      pdf.add(table);

      // Imagen (si existe)
      byte[] foto = d.getFoto();
      if (foto != null && foto.length > 0) {
        Image img = Image.getInstance(foto);
        img.scaleToFit(200, 200);
        img.setSpacingBefore(20);
        pdf.add(img);
      }

    } catch (DocumentException de) {
      throw new IOException(de.getMessage(), de);
    } finally {
      pdf.close();
    }
  }
}
