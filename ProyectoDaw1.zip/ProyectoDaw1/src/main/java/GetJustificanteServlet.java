

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URLConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Base64;

/**
 * Servlet implementation class GetJustificanteServlet
 */
@WebServlet("/GetJustificanteServlet")
public class GetJustificanteServlet extends HttpServlet {

  @Override
  protected void doGet(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException {
    // 1) Permitir CORS
    resp.setHeader("Access-Control-Allow-Origin", "*");
    // (opcionalmente podrías restringir a tu dominio: e.g. "http://localhost:8080")
    resp.setContentType("application/json; charset=UTF-8");

    int id = Integer.parseInt(req.getParameter("justificanteId"));
    try (
      Connection c = Bbdd.getConnection();
      PreparedStatement p = c.prepareStatement(
        "SELECT deuda_id, dni, email, archivo, estado FROM justificantes WHERE id=?")
    ) {
      p.setInt(1, id);
      try (ResultSet rs = p.executeQuery()) {
        if (!rs.next()) {
          resp.setStatus(404);
          resp.getWriter().write("{\"error\":\"No encontrado\"}");
          return;
        }
        byte[] blob = rs.getBytes("archivo");
        String base64 = Base64.getEncoder().encodeToString(blob);
        String mime = URLConnection.guessContentTypeFromStream(
                           new ByteArrayInputStream(blob));
        // Construimos el JSON
        String json = String.format(
          "{\"id\":%d,\"deuda_id\":%d,\"dni\":\"%s\",\"email\":\"%s\","
          + "\"mime\":\"%s\",\"base64\":\"%s\",\"estado\":\"%s\"}",
          id,
          rs.getInt("deuda_id"),
          rs.getString("dni"),
          rs.getString("email"),
          mime,
          base64,
          rs.getString("estado")
        );
        resp.getWriter().write(json);
      }
    } catch (Exception e) {
      resp.setStatus(500);
      resp.getWriter().write("{\"error\":\"" + e.getMessage() + "\"}");
      e.printStackTrace();
    }
  }

  // Si necesitas aceptar OPTIONS preflight:
  @Override
  protected void doOptions(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException {
    resp.setHeader("Access-Control-Allow-Origin", "*");
    resp.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    resp.setHeader("Access-Control-Allow-Headers", "Content-Type");
  }
}
