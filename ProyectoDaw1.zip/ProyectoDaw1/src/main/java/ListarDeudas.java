
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class ListarDeudas
 */
@WebServlet("/ListarDeudas")
public class ListarDeudas extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {

        // Permitir CORS para file://
        resp.setHeader("Access-Control-Allow-Origin", "*");
        resp.setContentType("text/html; charset=UTF-8");

        // Parámetro de orden
        String orden = req.getParameter("orden");
        // Modo: 'admin' para justificar, 'insertar' para eliminar
        String modo  = req.getParameter("modo");

        boolean permitirEliminar   = "insertar".equals(modo);
        boolean permitirJustificar = "admin".equals(modo);

        // Llama al método con los tres parámetros
        String tabla = Bbdd.listarDeudasHTML(orden, permitirEliminar, permitirJustificar);

        resp.getWriter().write(tabla);
    }
}