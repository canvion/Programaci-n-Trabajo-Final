import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.util.Locale;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

@WebServlet("/Deudas")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 1,  // 1 MB
    maxFileSize       = 1024 * 1024 * 10, // 10 MB
    maxRequestSize    = 1024 * 1024 * 15  // 15 MB
)
public class Deudas extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public Deudas() {
        super();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        resp.setHeader("Access-Control-Allow-Origin", "*");
        req.setCharacterEncoding("UTF-8");

        try {
            String deudaId          = req.getParameter("deudaId");
            String nombreApellidos = req.getParameter("nombre_apellidos");
            String fechaStr        = req.getParameter("fecha");
            String motivo          = req.getParameter("motivo");
            String cantidadStr     = req.getParameter("cantidad");
            String dni             = req.getParameter("dni");
            String email           = req.getParameter("email");
            Part fotoPart          = req.getPart("foto");

            // Validaciones básicas
            if (nombreApellidos == null || fechaStr == null || motivo == null ||
                cantidadStr == null || dni == null || email == null ||
                nombreApellidos.isEmpty() || fechaStr.isEmpty() ||
                motivo.isEmpty() || cantidadStr.isEmpty() ||
                dni.isEmpty() || email.isEmpty()) {
                throw new IllegalArgumentException("Todos los campos son obligatorios.");
            }
            double cantidad = Double.parseDouble(cantidadStr);

            // Si viene deudaId → ACTUALIZAR
            if (deudaId != null && !deudaId.isEmpty()) {
                int id = Integer.parseInt(deudaId);

                boolean nuevaFoto = fotoPart != null && fotoPart.getSize() > 0;
                String sql;
                if (nuevaFoto) {
                    sql = "UPDATE deudas SET "
                        + "nombre_apellidos=?, foto=?, fecha=?, motivo=?, cantidad=?, dni=?, email=? "
                        + "WHERE id=?";
                } else {
                    sql = "UPDATE deudas SET "
                        + "nombre_apellidos=?, fecha=?, motivo=?, cantidad=?, dni=?, email=? "
                        + "WHERE id=?";
                }

                try (Connection c = Bbdd.getConnection();
                     PreparedStatement p = c.prepareStatement(sql)) {

                    int idx = 1;
                    p.setString(idx++, nombreApellidos);

                    if (nuevaFoto) {
                        p.setBlob(idx++, fotoPart.getInputStream());
                    }

                    p.setDate(idx++, java.sql.Date.valueOf(fechaStr));
                    p.setString(idx++, motivo);
                    p.setDouble(idx++, cantidad);
                    p.setString(idx++, dni);
                    p.setString(idx++, email);
                    p.setInt(idx, id);

                    p.executeUpdate();
                }

                resp.setContentType("text/plain; charset=UTF-8");
                resp.getWriter().write("Deuda actualizada correctamente");
                return;
            }

            // — SINO — INSERTAR NUEVA
            if (fotoPart == null || fotoPart.getSize() == 0) {
                throw new IllegalArgumentException("La foto es obligatoria.");
            }
            try (InputStream fotoStream = fotoPart.getInputStream()) {
                Bbdd.insertarDeuda(
                    nombreApellidos,
                    fotoStream,
                    fechaStr,
                    motivo,
                    cantidad,
                    dni,
                    email
                );
            }
            resp.setContentType("text/plain; charset=UTF-8");
            resp.getWriter().write("Deuda insertada correctamente.");

        } catch (Exception e) {
            resp.setStatus(500);
            resp.getWriter().write("Error procesando deuda: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        resp.setHeader("Access-Control-Allow-Origin", "*");
        resp.setCharacterEncoding("UTF-8");

        String idParam = req.getParameter("id");
        if (idParam != null && !idParam.isEmpty()) {
            // — GET de una sola deuda en JSON —
            try {
                int id = Integer.parseInt(idParam);
                Deuda d = Bbdd.getDeudaPorId(id);

                resp.setContentType("application/json; charset=UTF-8");

                // Formatear con Locale.US para usar punto decimal
                String json = String.format(
                    Locale.US,
                    "{\"id\":%d,\"nombre_apellidos\":\"%s\",\"fecha\":\"%s\","
                  + "\"motivo\":\"%s\",\"cantidad\":%.2f,\"dni\":\"%s\",\"email\":\"%s\"}",
                    d.getId(),
                    d.getNombreApellidos(),
                    d.getFecha().toString(),
                    d.getMotivo(),
                    d.getCantidad(),
                    d.getDni(),
                    d.getEmail()
                );

                resp.getWriter().write(json);
            } catch (Exception e) {
                resp.setStatus(500);
                resp.setContentType("application/json; charset=UTF-8");
                resp.getWriter().write("{\"error\":\"" + e.getMessage() + "\"}");
                e.printStackTrace();
            }
            return;
        }

        // — LISTAR PARA TABLA —
        String orden = req.getParameter("orden");
        String origin = req.getHeader("referer");
        boolean permitirEliminar   = origin != null && origin.contains("insertar_deuda.html");
        boolean permitirJustificar = origin != null && origin.contains("admin.html");
        String tabla = Bbdd.listarDeudasHTML(orden, permitirEliminar, permitirJustificar);

        resp.setContentType("text/html; charset=UTF-8");
        resp.getWriter().write(tabla);
    }
}
