


import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setHeader("Access-Control-Allow-Origin", "*"); // Importante para file://
        response.setHeader("Access-Control-Allow-Headers", "*"); // Para permitir Content-Type

        String user = request.getParameter("username");
        String pass = request.getParameter("password");

        boolean valid = false;

        try (Connection con = Bbdd.getConnection();
             PreparedStatement pst = con.prepareStatement("SELECT * FROM usuarios WHERE username=? AND password=?")) {

            pst.setString(1, user);
            pst.setString(2, pass);

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                valid = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        response.setContentType("text/plain");

        if (valid) {
            response.getWriter().write("OK");
        } else {
            response.getWriter().write("ERROR");
        }
    }
}

