
document.addEventListener('DOMContentLoaded', () => {
  const params = new URLSearchParams(location.search);
  const justId = params.get('justificanteId');
  if (!justId) return document.getElementById('mensaje').innerText = 'ID no proporcionado';

  fetch(`${baseURL}/GetJustificanteServlet?justificanteId=${justId}`)
    .then(r => r.ok ? r.json() : Promise.reject(r.status))
    .then(data => {
      // Mostrar datos
      document.getElementById('datos').innerHTML = `
        <p><strong>ID Justificante:</strong> ${data.id}</p>
        <p><strong>ID Deuda:</strong> ${data.deuda_id}</p>
        <p><strong>DNI:</strong> ${data.dni}</p>
        <p><strong>Email:</strong> ${data.email}</p>
      `;

      // Mostrar archivo
      if (data.mime.startsWith('image/')) {
        document.getElementById('visor').innerHTML =
          `<img src="data:${data.mime};base64,${data.base64}" style="max-width:100%"/>`;
      } else {
        document.getElementById('visor').innerHTML =
          `<embed src="data:${data.mime};base64,${data.base64}" width="100%" height="600px"/>`;
      }

      // Botón marcar como pagada
      document.getElementById('btnMarcar').addEventListener('click', () => {
        fetch(`${baseURL}/MarcarPagadaServlet?justificanteId=${justId}`, {
          method: 'POST'
        })
        .then(r => r.ok ? r.text() : Promise.reject(r.status))
        .then(msg => {
          document.getElementById('mensaje').innerText = msg;
        })
        .catch(e => {
          console.error(e);
          document.getElementById('mensaje').innerText = 'Error al marcar como pagada';
        });
      });

      // ✅ Botón rechazar justificante
      document.getElementById('btnRechazar').addEventListener('click', () => {
        if (confirm('¿Estás seguro de que deseas rechazar y eliminar este justificante?')) {
          fetch(`${baseURL}/EliminarJustificanteServlet?justificanteId=${justId}`, {
            method: 'POST'
          })
          .then(r => r.ok ? r.text() : Promise.reject(r.status))
          .then(msg => {
            document.getElementById('mensaje').innerText = msg;
            setTimeout(() => {
              window.location.href = `${baseURL}/admin.html`;
            }, 2000);
          })
          .catch(e => {
            console.error(e);
            document.getElementById('mensaje').innerText = 'Error al rechazar justificante';
          });
        }
      });
    })
    .catch(err => {
      console.error(err);
      document.getElementById('mensaje').innerText = 'Error al cargar el justificante';
    });
});
