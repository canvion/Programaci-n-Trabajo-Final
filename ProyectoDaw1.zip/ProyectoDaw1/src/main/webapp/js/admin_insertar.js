// ✅ baseURL viene desde config.js

document.addEventListener('DOMContentLoaded', () => {
  cargarDeudas(); // carga inicial
});

function cargarDeudas(orden) {
  const cont = document.getElementById('tablaDeudas');
  cont.innerText = 'Cargando...';

  let url = `${baseURL}/ListarDeudas?modo=insertar`;
  if (orden === 'asc' || orden === 'desc') url += '&orden=' + orden;
  url += '&nocache=' + Date.now();

  fetch(url)
    .then(r => {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.text();
    })
    .then(html => {
      cont.innerHTML = html;
      
      // — ELIMINAR —
      document.querySelectorAll('.btnEliminar').forEach(btn => {
        btn.addEventListener('click', () => {
          const id = btn.dataset.id;
          if (confirm(`¿Estás seguro de eliminar la deuda #${id}?`)) {
            eliminarDeuda(id);
          }
        });
      });

            // — EDITAR —
      document.querySelectorAll('.btnEditar').forEach(btn => {
        btn.addEventListener('click', () => {
          const id = btn.dataset.id;
          // Asegúrate de incluir baseURL para resolver bien la ruta
          window.open(`${baseURL}/editar_deuda.html?deudaId=${id}`, '_blank');
        });
      });

      // ← Nuevo: Listener para cada botón PDF
      document.querySelectorAll('.btnPdf').forEach(btn => {
        btn.addEventListener('click', () => {
          const id = btn.dataset.id;
          window.open(`${baseURL}/PdfDeudaServlet?id=${id}`, '_blank');
        });
      });

    })
    .catch(err => {
      console.error(err);
      cont.innerText = 'Error al cargar las deudas.';
    });
}


function eliminarDeuda(id) {
  fetch(`${baseURL}/EliminarDeudaServlet?id=${id}`, {
    method: 'GET'
  })
  .then(r => {
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.text();
  })
  .then(msg => {
    alert(msg);
    cargarDeudas(); // recarga sin orden
  })
  .catch(err => {
    console.error(err);
    alert('Error al eliminar la deuda');
  });
}

// ✅ PASO 3: función para precargar el formulario con los datos de una deuda
function cargarDatosDeuda(id) {
  fetch(`${baseURL}/Deudas?id=${id}`)
  .then(r => r.text())          // 1) Recoges la respuesta como texto
  .then(txt => {
    console.log("RESPUESTA RAW:", txt);  // 2) La ves en consola
    return JSON.parse(txt);               // 3) Luego parseas manualmente
  })
    .then(data => {
      document.getElementById('deudaId').value = data.id;
      document.getElementById('nombre_apellidos').value = data.nombre;
      document.getElementById('fecha').value = data.fecha;
      document.getElementById('motivo').value = data.motivo;
      document.getElementById('cantidad').value = data.cantidad;
      document.getElementById('dni').value = data.dni;
      document.getElementById('email').value = data.email;
      // ⚠️ No se puede precargar el archivo adjunto (foto/justificante)
    })
    .catch(err => {
      console.error(err);
      alert('Error al cargar datos de la deuda');
    });
}
