document.addEventListener('DOMContentLoaded', () => {
    const params = new URLSearchParams(location.search);
    const id = params.get('deudaId');
    if (!id) {
      document.getElementById('mensaje').innerText = 'ID de deuda no proporcionado';
      return;
    }
  
    // Carga inicial de datos
    fetch(`${baseURL}/Deudas?id=${id}`)
      .then(res => res.json())
      .then(d => {
        document.getElementById('deudaId').value         = d.id;
        document.getElementById('nombre_apellidos').value = d.nombre_apellidos;
        document.getElementById('fecha').value           = d.fecha;
        document.getElementById('motivo').value          = d.motivo;
        document.getElementById('cantidad').value        = d.cantidad;
        document.getElementById('dni').value             = d.dni;
        document.getElementById('email').value           = d.email;
      })
      .catch(err => {
        console.error(err);
        document.getElementById('mensaje').innerText = 'Error al cargar datos';
      });
  
    // Volver: cierra la pestaña
    document.getElementById('volverBtn').addEventListener('click', () => {
      window.close();
    });
  
    // Envío de formulario para actualizar
    document.getElementById('editarForm').addEventListener('submit', e => {
      e.preventDefault();
      const form = document.getElementById('editarForm');
      const formData = new FormData(form);
  
      fetch(`${baseURL}/Deudas`, {
        method: 'POST',
        body: formData
      })
      .then(res => res.text())
      .then(msg => {
        document.getElementById('mensaje').innerText = msg;
        // Opcional: cerrar pestaña tras 2s y refrescar padre
        setTimeout(() => {
          window.opener.location.reload();
          window.close();
        }, 2000);
      })
      .catch(err => {
        console.error(err);
        document.getElementById('mensaje').innerText = 'Error al actualizar';
      });
    });
  });
  