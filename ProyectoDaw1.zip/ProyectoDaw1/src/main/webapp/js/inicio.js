document.addEventListener('DOMContentLoaded', () => {
  let destino = "";

  // Función para abrir el modal
  function abrirLogin(dest) {
    destino = dest;
    document.getElementById('loginModal').style.display = 'flex';
  }

  // Evento para el botón "Insertar Deuda"
  document.getElementById('insertarBtn').addEventListener('click', () => {
    abrirLogin('insertar_deuda.html');
  });

  // Evento para el botón "Ver Deudas"
  document.getElementById('verDeudasBtn').addEventListener('click', () => {
    abrirLogin('admin.html');
  });

  // Evento para el botón "Entrar" del modal
  document.getElementById('modalLoginBtn').addEventListener('click', () => {
    const user = document.getElementById('modalUser').value;
    const pass = document.getElementById('modalPass').value;

    if (user === 'adriancervera' && pass === '12345678') {
      sessionStorage.setItem('isAdmin', 'true');
      window.location.href = destino;
    } else {
      alert('Usuario o contraseña incorrectos');
    }
  });
});
