document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('btnAsc')
          .addEventListener('click', () => listarDeudas('asc'));
  document.getElementById('btnDesc')
          .addEventListener('click', () => listarDeudas('desc'));
  document.getElementById('btnListar')
          .addEventListener('click', () => listarDeudas());
});

function listarDeudas(orden) {
  const cont = document.getElementById('tablaDeudas');
  cont.innerHTML = '';  // limpia tabla anterior

  let url = `${baseURL}/ListarDeudas?modo=admin`;
  if (orden === 'asc' || orden === 'desc') url += '&orden=' + orden;
  url += '&nocache=' + Date.now();  // evita caché

  fetch(url)
    .then(r => {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.text();
    })
    .then(html => {
      cont.innerHTML = html;

      // — Listener para cada botón "Justificar" —
      document.querySelectorAll('.btnJustificar').forEach(btn => {
        btn.addEventListener('click', () => {
          const deudaId = btn.dataset.id;
          window.location.href = 
            `${baseURL}/justificante.html?deudaId=${deudaId}`;
        });
      });

      // — Listener para cada botón "PDF" —
      document.querySelectorAll('.btnPdf').forEach(btn => {
        btn.addEventListener('click', () => {
          const deudaId = btn.dataset.id;
          window.open(
            `${baseURL}/PdfDeudaServlet?id=${deudaId}`, 
            '_blank'
          );
        });
      });
    })
    .catch(err => {
      console.error(err);
      cont.innerText = 'Error al cargar las deudas';
    });
}
