
document.addEventListener('DOMContentLoaded', () => {
    cargarJustificantes();
  });
  
  function cargarJustificantes() {
    const cont = document.getElementById('tablaJustificantes');
    cont.innerText = 'Cargando justificantes…';
  
    fetch(`${baseURL}/JustificanteServlet?nocache=` + Date.now())
      .then(r => {
        if (!r.ok) throw new Error(r.status);
        return r.text();
      })
      .then(html => {
        cont.innerHTML = html;
        document.querySelectorAll('.btnRevisar').forEach(btn => {
          btn.addEventListener('click', () => {
            const justId = btn.dataset.id;
            window.location.href = `revisar_justificacion.html?justificanteId=${justId}`;
          });
        });
      })
      .catch(err => {
        console.error(err);
        cont.innerText = 'Error al cargar justificantes';
      });
  }
  