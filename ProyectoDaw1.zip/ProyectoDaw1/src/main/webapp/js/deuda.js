
document.getElementById('deudaForm').addEventListener('submit', enviarDeuda);

function enviarDeuda(e) {
  e.preventDefault();
  const form = document.getElementById('deudaForm');
  const formData = new FormData(form);

  fetch(`${baseURL}/Deudas`, {
    method: "POST",
    body: formData
  })
  .then(res => res.text())
  .then(msg => {
    document.getElementById('mensaje').innerText = msg;
    form.reset();
  })
  .catch(err => {
    console.error(err);
    document.getElementById('mensaje').innerText = "Error al enviar los datos";
  });
}
