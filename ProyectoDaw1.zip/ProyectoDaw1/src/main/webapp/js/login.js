
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('loginForm').addEventListener('submit', (e) => {
      e.preventDefault();
  
      const user = document.getElementById('username').value;
      const pass = document.getElementById('password').value;
  
      fetch(`${baseURL}/LoginServlet`, {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: `username=${encodeURIComponent(user)}&password=${encodeURIComponent(pass)}`
      })
      .then(res => res.text())
      .then(text => {
        if (text.trim() === "OK") {
          sessionStorage.setItem('isAdmin', 'true');
          location.href = 'insertar_deuda.html';
        } else {
          document.getElementById('error').textContent = 'Usuario o contraseña incorrectos';
        }
      });
    });
  });
  