// Solo proteger insertar_deuda.html
if (location.pathname.endsWith('insertar_deuda.html')) {
  if (sessionStorage.getItem('isAdmin') !== 'true') {
    location.href = 'login.html';
  }
}

// Logout
window.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('logoutBtn');
  if (btn) {
    btn.addEventListener('click', () => {
      sessionStorage.removeItem('isAdmin');
      location.href = 'inicio.html';
    });
  }
});
