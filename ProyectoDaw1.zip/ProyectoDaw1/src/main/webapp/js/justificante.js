
document.addEventListener('DOMContentLoaded', () => {
  const params = new URLSearchParams(location.search);
  const deudaId = params.get('deudaId');
  if (!deudaId) {
    document.getElementById('mensaje').innerText = 'ID de deuda no proporcionado';
    return;
  }

  // Asignar el hidden
  document.getElementById('deudaId').value = deudaId;

  // Precargar DNI y Email
  fetch(`${baseURL}/Deudas?id=${deudaId}`)
    .then(res => {
      if (!res.ok) throw new Error('HTTP ' + res.status);
      return res.json();
    })
    .then(d => {
      console.log('Datos de deuda:', d);
      // Asegúrate de que en tu HTML tienes:
      // <input type="text" id="dni" name="dni" ...>
      // <input type="email" id="email" name="email" ...>
      document.getElementById('dni').value   = d.dni;
      document.getElementById('email').value = d.email;
    })
    .catch(err => {
      console.error('Error al cargar datos de deuda:', err);
      document.getElementById('mensaje').innerText = 'No se pudieron cargar los datos';
    });

  // Manejo del envío del justificante
  document.getElementById('justForm').addEventListener('submit', e => {
    e.preventDefault();
    const formData = new FormData(e.target);

    fetch(`${baseURL}/JustificanteServlet`, {
      method: 'POST',
      body: formData
    })
    .then(r => {
      if (!r.ok) throw new Error(r.status);
      return r.text();
    })
    .then(msg => {
      document.getElementById('mensaje').innerText = msg;
      e.target.reset();
      // Redirige a admin.html después de 2 segundos
      setTimeout(() => {
        window.location.href = `${baseURL}/admin.html`;
      }, 2000);
    })
    .catch(err => {
      console.error(err);
      document.getElementById('mensaje').innerText = 'Error al enviar justificante';
    });
  });
});
